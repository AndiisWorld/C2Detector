import re
import requests
import socket
import psutil

# API Keys for VirusTotal and AbuseIPDB
VIRUSTOTAL_API_KEY = "a770cbdf32172aec74cace3043195116bc5ac29580c0a5a30196d53b3bfa1c29"
ABUSEIPDB_API_KEY = "4beeaba7189981c68279e4d9372aed3bf7ae793c7a9db513f08f5886a6239ffff4f2f7e98bf5e12b"

# File paths
LOG_FILE = "potential_beaconing.txt"
RESULTS_FILE = "ip_check_results.txt"

# Extract unique IPs from the log file
def get_ip_from_adapter(adapter_name):
    """
    Get the IP address of a specific network adapter by name.
    """
    for interface, addrs in psutil.net_if_addrs().items():
        if interface == adapter_name:
            for addr in addrs:
                if addr.family == socket.AF_INET:  # IPv4 Address
                    return addr.address
    return None  # Return None if no matching adapter found

def extract_unique_ips(log_file, adapter_name="Ethernet"):
    try:
        # Get the IP address from the specified adapter
        current_ip = get_ip_from_adapter(adapter_name)
        if not current_ip:
            print(f"Could not find IP for adapter: {adapter_name}")
            return set()

        with open(log_file, "r") as file:
            content = file.read()

        # Regular expression to find IP addresses
        ip_pattern = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        ips = ip_pattern.findall(content)

        # Remove duplicates and exclude the current system IP
        unique_ips = set(ips)
        if current_ip in unique_ips:
            unique_ips.remove(current_ip)

        return unique_ips
    except FileNotFoundError:
        print(f"File not found: {log_file}")
        return set()
    except Exception as e:
        print(f"An error occurred: {e}")
        return set()

# Check IP in VirusTotal
def check_ip_virustotal(ip):
    url = f"https://www.virustotal.com/api/v3/ip_addresses/{ip}"
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        analysis_stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        malicious_count = (
            analysis_stats.get("malicious", 0)
            + analysis_stats.get("phishing", 0)
            + analysis_stats.get("suspicious", 0)
        )

        return f"VirusTotal: {malicious_count} malicious reports"
    else:
        return f"VirusTotal: Failed to fetch data (Status Code: {response.status_code})"

# Check IP in AbuseIPDB
def check_ip_abuseipdb(ip):
    url = "https://api.abuseipdb.com/api/v2/check"
    params = {"ipAddress": ip, "maxAgeInDays": 90}
    headers = {"Key": ABUSEIPDB_API_KEY, "Accept": "application/json"}
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        data = response.json()
        abuse_score = data.get("data", {}).get("abuseConfidenceScore", 0)
        return f"AbuseIPDB: {abuse_score}% confidence of abuse"
    else:
        return f"AbuseIPDB: Failed to fetch data (Status Code: {response.status_code})"

# Main function to check all IPs
def check_ips():
    ips = extract_unique_ips(LOG_FILE)
    if not ips:
        print("No IPs found in the log file.")
        return

    print(f"Checking {len(ips)} unique IPs...")
    results = []

    for ip in ips:
        print(f"Checking IP: {ip}")
        vt_result = check_ip_virustotal(ip)
        abuseipdb_result = check_ip_abuseipdb(ip)
        results.append(f"IP: {ip}\n{vt_result}\n{abuseipdb_result}\n")

    # Write results to a file
    with open(RESULTS_FILE, "w") as file:
        file.write("\n".join(results))

    print(f"Results saved to {RESULTS_FILE}")

if __name__ == "__main__":
    check_ips()