import tkinter as tk
from tkinter import messagebox, ttk
import subprocess
import os
import psutil
import socket

# Global variable to store the subprocess handle
current_process = None


def get_local_ip():
    """
    Get the local IP address of the system.
    """
    hostname = socket.gethostname()
    return socket.gethostbyname(hostname)


def kill_process(ip, port):
    """
    Find and kill the process making a connection to the specified IP and port.
    """
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.raddr and conn.raddr.ip == ip and conn.raddr.port == int(port):
                pid = conn.pid  # Get the process ID
                if pid:
                    process = psutil.Process(pid)
                    process.terminate()  # Gracefully terminate the process
                    process.wait(timeout=3)  # Wait for the process to terminate
                    messagebox.showinfo("Success", f"Process {process.name()} (PID: {pid}) terminated.")
                    return
        messagebox.showerror("Error", f"No process found for connection to {ip}:{port}.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to kill process: {e}")


def kill_process_dialog(ip, port):
    """
    Dialog to confirm and trigger the killing of a process.
    """
    result = messagebox.askyesno("Kill Process", f"Do you want to kill the process connected to {ip}:{port}?")
    if result:
        kill_process(ip, port)


def kill_selected_process():
    """
    Kills the process for the selected IP in the Treeview.
    """
    selected_item = tree.focus()  # Get the selected row
    if not selected_item:
        messagebox.showwarning("No Selection", "Please select a process to kill.")
        return

    # Get values from the selected row
    values = tree.item(selected_item, "values")
    if len(values) < 1:
        messagebox.showerror("Error", "Unable to retrieve IP from the selected row.")
        return

    ip = values[0]  # IP is the first column
    port = 5000  # Use the appropriate logic to get the port (defaulting to 80 here)

    # Confirm and kill the process
    kill_process_dialog(ip, port)


# Function to start everything via the wrapper script
def start_all():
    global current_process
    try:
        # Run the wrapper script in a separate thread so that the UI remains responsive
        current_process = subprocess.Popen(["python", "wrapper.py"])
        status_label.config(text="Started all tasks...")
        start_button.config(state="disabled")  # Disable the button to prevent multiple clicks
        stop_button.config(state="normal")
        update_results()  # Initially load results
        check_for_updates()  # Start periodic check for updates
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")


def stop_all():
    """
    Stops all running tasks by terminating the wrapper process.
    """
    global current_process
    if current_process:
        # Kill the current subprocess (wrapper.py)
        current_process.terminate()
        status_label.config(text="Tasks stopped.")
        start_button.config(state="normal")
        stop_button.config(state="disabled")
    else:
        messagebox.showerror("Error", "No task is running to stop.")


def update_results():
    """
    Reads ip_check_results.txt and updates the Treeview with new results.
    """
    try:
        # Get the local system's IP address
        local_ip = get_local_ip()
        local_ip_excluded = False  # Track whether we've excluded the local IP

        with open("ip_check_results.txt", "r") as file:
            content = file.read()
            if content.strip():  # Check if file is not empty
                tree.delete(*tree.get_children())  # Clear previous results
                entries = content.split("\n\n")  # Split by double newline
                for entry in entries:
                    lines = entry.splitlines()
                    if len(lines) >= 3:
                        ip_line = lines[0].strip()
                        virus_line = lines[1].strip()
                        abuse_line = lines[2].strip()

                        if ip_line.startswith("IP:") and virus_line.startswith("VirusTotal:") and abuse_line.startswith("AbuseIPDB:"):
                            ip = ip_line.split(": ")[1]
                            virus_result = virus_line.split(": ")[1]
                            abuse_result = abuse_line.split(": ")[1]

                            # Exclude the local system's IP
                            if ip == local_ip:
                                if not local_ip_excluded:
                                    print(f"Excluding local IP: {local_ip}")
                                    local_ip_excluded = True
                                continue  # Skip adding the local IP to the results

                            # Add the row to the Treeview
                            row_id = tree.insert("", "end", values=(ip, virus_result, abuse_result))
            else:
                # No content available
                tree.delete(*tree.get_children())
                tree.insert("", "end", values=("No results available yet...", "", ""))
    except FileNotFoundError:
        tree.delete(*tree.get_children())
        tree.insert("", "end", values=("ip_check_results.txt not found!", "", ""))
    except Exception as e:
        print(f"Error processing ip_check_results.txt: {e}")


def check_for_updates():
    """
    Periodically checks for updates in ip_check_results.txt and refreshes the display.
    """
    update_results()  # Call the update function to refresh the display
    root.after(2000, check_for_updates)  # Check every 2 seconds


# Main application window
root = tk.Tk()
root.title("Network Monitor")
root.geometry("700x600")  # Adjusted height for the extra button

# Header Label
header_label = tk.Label(root, text="C2 Sentinel", font=("Arial", 16, "bold"), fg="blue")
header_label.pack(pady=10)

# Frame for Buttons and Status
control_frame = tk.Frame(root)
control_frame.pack(pady=10, fill=tk.X, padx=20)

# Status Label
status_label = tk.Label(
    control_frame, text="Status: Idle", font=("Arial", 12), width=50, anchor="w", bg="#f0f0f0", relief="sunken"
)
status_label.grid(row=0, column=0, padx=10, pady=10, columnspan=2, sticky="ew")

# Start and Stop Buttons
start_button = tk.Button(control_frame, text="Start Analyzing", command=start_all, width=20)
start_button.grid(row=1, column=0, padx=10, pady=10)

stop_button = tk.Button(control_frame, text="Stop All", command=stop_all, width=20, state="disabled")
stop_button.grid(row=1, column=1, padx=10, pady=10)

# Frame for Results Section
result_frame = tk.Frame(root)
result_frame.pack(pady=10, fill=tk.BOTH, expand=True, padx=20)

# Treeview for displaying results in a table format
tree = ttk.Treeview(result_frame, columns=("IP", "VirusTotal", "AbuseIPDB"), show="headings")
tree.heading("IP", text="IP Address")
tree.heading("VirusTotal", text="VirusTotal Result")
tree.heading("AbuseIPDB", text="AbuseIPDB Result")

# Configure the column widths
tree.column("IP", width=150, anchor="center")
tree.column("VirusTotal", width=150, anchor="center")
tree.column("AbuseIPDB", width=150, anchor="center")

# Scrollbars
scrollbar_y = ttk.Scrollbar(result_frame, orient="vertical", command=tree.yview)
scrollbar_x = ttk.Scrollbar(result_frame, orient="horizontal", command=tree.xview)

tree.config(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)

# Pack Treeview and Scrollbars
tree.pack(fill=tk.BOTH, expand=True)
scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)
scrollbar_x.pack(side=tk.BOTTOM, fill=tk.X)

# Add "Kill Selected Process" Button
kill_button = tk.Button(root, text="Kill Selected Process", command=kill_selected_process)
kill_button.pack(pady=10)

# Start the main application loop
root.mainloop()
