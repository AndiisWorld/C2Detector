import scapy.all as scapy
from datetime import datetime

# Function to capture and filter HTTP packets
def capture_http(packet):
    if packet.haslayer(scapy.IP) and packet.haslayer(scapy.TCP):
        ip_src = packet[scapy.IP].src
        ip_dst = packet[scapy.IP].dst
        tcp_sport = packet[scapy.TCP].sport
        tcp_dport = packet[scapy.TCP].dport

        # Filter HTTP request (check for GET, POST, etc. methods)
        if packet.haslayer(scapy.Raw):
            payload = packet[scapy.Raw].load.decode(errors="ignore")
            if "HTTP" in payload.upper():
                # Extract the HTTP method and URL (if possible)
                method = None
                url = None
                size = len(payload)

                # Extract HTTP method and URL from the first line of the HTTP request
                lines = payload.split("\r\n")
                if len(lines) > 0:
                    first_line = lines[0]
                    if "GET" in first_line or "POST" in first_line or "PUT" in first_line or "DELETE" in first_line:
                        method, url = first_line.split(" ")[:2]

                # Get the current timestamp for the log
                timestamp = datetime.now()

                # Write the formatted log to the file
                log_data = f"{timestamp} | {ip_src}:{tcp_sport} -> {ip_dst}:{tcp_dport} | {packet.proto} | {method} | {url} | {size} bytes\n"
                with open("http_traffic_log.txt", "a", encoding="utf-8") as log_file:
                    log_file.write(log_data)
                print(log_data)  # Optional: print to console for real-time monitoring

# Start sniffing traffic on the default interface (you may need to specify the interface if needed)
scapy.sniff(prn=capture_http, store=0, filter="tcp", iface="Ethernet")