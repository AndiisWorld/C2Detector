import subprocess
import time
import threading
import signal

# Function to start the packet capture process
def start_packet_capture(stop_event):
    # Start packet capture process (capture for 1 minute)
    capture_process = subprocess.Popen(["python", "packetcapture.py"])
    
    # Wait for 1 minute (60 seconds) before stopping the capture
    time.sleep(60)  # Capture packets for 60 seconds
    if not stop_event.is_set():
        capture_process.terminate()  # Terminate the capture process after 1 minute
        return capture_process
    return None

# Function to start checking and validating logs
def start_checking_and_validating():
    # Run checklog and validate
    subprocess.run(["python", "checklog.py"], check=True)
    time.sleep(2)  # Wait for a short time before running the validate process
    subprocess.run(["python", "validate.py"], check=True)
    time.sleep(1)
    subprocess.run(["python", "telegrambot.py"], check=True)

# Wrapper function that runs both tasks
def run_all_tasks(stop_event):
    # Start packet capture and stop after 1 minute
    capture_process = start_packet_capture(stop_event)

    # If the stop event is set, terminate the process
    if stop_event.is_set():
        if capture_process:
            capture_process.terminate()
        return

    # Start checking and validating logs after packet capture stops
    start_checking_and_validating()

    return "Process Completed"

# Stop event to control the flow
def stop_process(stop_event):
    stop_event.set()

if __name__ == "__main__":
    # Create a stop event to control when to terminate the process
    stop_event = threading.Event()
    run_all_tasks(stop_event)