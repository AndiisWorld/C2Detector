from datetime import datetime
import os
from plyer import notification
from win10toast import ToastNotifier

# Function to parse a single log line
def parse_log_line(line):
    try:
        timestamp_str, connection_info = line.split(" | ", 1)
        timestamp = datetime.strptime(timestamp_str.strip(), "%Y-%m-%d %H:%M:%S.%f")
        ip_info, proto, method, url, size_info = connection_info.split(" | ")
        src_ip_port, dst_ip_port = ip_info.split(" -> ")
        
        src_ip, src_port = src_ip_port.split(":")
        dst_ip, dst_port = dst_ip_port.split(":")
        size = int(size_info.split(" ")[0])  # Extract size as an integer
        
        return {
            "timestamp": timestamp,
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "dst_port": dst_port,
            "protocol": proto.strip(),
            "method": method.strip(),
            "url": url.strip(),
            "size": size
        }
    except Exception as e:
        print(f"Error parsing log line: {line.strip()} - {e}")
        return None

# Function to check if collected packets have consistent beaconing intervals
def check_beaconing_intervals(packets, expected_interval=10, tolerance=0.2):
    time_diffs = []
    for i in range(1, len(packets)):
        diff = (packets[i]["timestamp"] - packets[i - 1]["timestamp"]).total_seconds()
        time_diffs.append(diff)

    avg_interval = sum(time_diffs) / len(time_diffs) if time_diffs else 0
    for diff in time_diffs:
        if abs(diff - avg_interval) > (avg_interval * tolerance):
            return False, time_diffs
    return True, time_diffs 

# Function to send a notification

def send_notification(title, message):
    toaster = ToastNotifier()
    toaster.show_toast(
        title,  # The title of the notification
        message,  # The message of the notification
        duration=4,  # Duration in seconds (optional)
        icon_path="Picture1.ico"
    )

# Function to identify unique conversations in the log
def get_unique_conversations(logs):
    conversations = set()
    for log in logs:
        conversations.add((log["src_ip"], log["dst_ip"], log["dst_port"], log["url"]))
    return conversations

# Function to filter logs for a specific conversation
def filter_logs_for_conversation(logs, conversation):
    src_ip, dst_ip, dst_port, url = conversation
    return [
        log for log in logs
        if log["src_ip"] == src_ip and log["dst_ip"] == dst_ip and
           log["dst_port"] == dst_port and log["url"] == url
    ]

# Main function to analyze the log file
def analyze_log_file(file_path):
    if not os.path.exists(file_path):
        print(f"Log file '{file_path}' not found.")
        return

    # Load all logs into memory
    logs = []
    with open(file_path, "r",encoding="utf-8") as file:
        for line in file:
            parsed_log = parse_log_line(line)
            if parsed_log:
                logs.append(parsed_log)

    if not logs:
        print("No valid log entries found.")
        return

    # Identify unique conversations
    unique_conversations = get_unique_conversations(logs)
    print(f"Found {len(unique_conversations)} unique conversations.")

    # Analyze each conversation
    for conversation in unique_conversations:
        matching_logs = filter_logs_for_conversation(logs, conversation)
        
        if len(matching_logs) >= 5:
            is_beaconing, time_diffs = check_beaconing_intervals(matching_logs)
            if is_beaconing:
                src_ip, dst_ip, dst_port, url = conversation
                title = "Potential Beaconing Activity Detected"
                message = (f"Src: {src_ip} -> Dst: {dst_ip}:{dst_port}\n"
                           f"URL: {url}\n"
                           f"Avg Interval: {sum(time_diffs)/len(time_diffs):.2f} seconds")
                
                # Send a notification
                send_notification(title, message)
                
                # Log to potential_beaconing.txt
                with open("potential_beaconing.txt", "a", encoding="utf-8") as beacon_file:
                    beacon_file.write(f"{title}\n")
                    beacon_file.write(message + "\n")
                    beacon_file.write("-" * 80 + "\n")
                
                print("Potential beaconing activity detected:")
                for packet in matching_logs:
                    log_entry = (f"{packet['timestamp']} | {packet['src_ip']} -> {packet['dst_ip']}:{packet['dst_port']} | "
                                 f"{packet['protocol']} | {packet['method']} | {packet['url']} | {packet['size']} bytes")
                    print(log_entry)
                    
                    # Save each packet's details to the log file
                    with open("potential_beaconing.txt", "a") as beacon_file:
                        beacon_file.write(log_entry + "\n")
                print(f"Time differences: {time_diffs}")
                with open("potential_beaconing.txt", "a") as beacon_file:
                    beacon_file.write(f"Time differences: {time_diffs}\n")
                    beacon_file.write("=" * 80 + "\n")
            else:
                print(f"Conversation {conversation} has no consistent beaconing intervals.")
        else:
            print(f"Conversation {conversation} does not have enough packets for analysis.")


# Run the analysis
log_file_path = "http_traffic_log.txt"
analyze_log_file(log_file_path)