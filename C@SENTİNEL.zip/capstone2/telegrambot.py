import requests
import os

# Telegram Bot Token and Chat ID
BOT_TOKEN = "8086156899:AAHJEDwUZFml19F7t9dr5c0tBRpzM4skAsg"
CHAT_ID = "886967846"

def send_telegram_message(message):
    """
    Send a message to Telegram chat.
    """
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "Markdown"  # Optional: Formats text (use "HTML" if preferred)
    }

    try:
        response = requests.post(url, json=payload)  # Using JSON payload
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx or 5xx)
        print(f"Telegram message sent: {message}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to send Telegram message: {e}")

def extract_and_notify():
    """
    Extracts data from ip_check_results.txt to send a structured warning via Telegram.
    """
    # File path for ip_check_results.txt
    results_file = "ip_check_results.txt"

    try:
        # Check if results file exists and read
        if os.path.exists(results_file):
            with open(results_file, "r") as rf:
                results_content = rf.read()
        else:
            results_content = ""

        # Process ip_check_results.txt
        warnings = []
        if results_content.strip():
            entries = results_content.split("\n\n")
            for entry in entries:
                lines = entry.splitlines()
                if len(lines) >= 3:
                    ip_line = lines[0].strip()
                    virus_line = lines[1].strip()
                    abuse_line = lines[2].strip()

                    if ip_line.startswith("IP:") and virus_line.startswith("VirusTotal:") and abuse_line.startswith("AbuseIPDB:"):
                        ip = ip_line.split(": ")[1]
                        virus_result = virus_line.split(": ")[1]
                        abuse_result = abuse_line.split(": ")[1]

                        warnings.append(
                            f"""
🚨 **Network Threat Detected!** 🚨
- **IP Address:** {ip}
- **VirusTotal Report:** {virus_result}
- **AbuseIPDB Score:** {abuse_result}
"""
                        )

        # Send warnings via Telegram
        if warnings:
            for warning in warnings:
                send_telegram_message(warning)
        else:
            print("No warnings to send.")

    except Exception as e:
        print(f"Error while extracting and notifying: {e}")

# Run the function
extract_and_notify()